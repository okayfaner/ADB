# DistributedDatabase
# Author: Xi Huang(N12297109), Oukan Fan(N16731193)
Replicated Concurrency Control and Recovery Distributed Database for NYU Advanced Database Course.


- DistributedDatabase.changeit
Please change the extension .changeit to .jar (to avoid Gmail blocking) and you will get the executable jar file "DistributedDatabase.jar", which we got from all the compile files of our project. 

Our project supports reading the input from a single file, just use our DistributedDatabase.jar file and the path of the input file as the first parameter.
such as"java -jar DistributedDatabase.jar path/to/your/input.txt".

And our project will output the process and result of this input to standard output, which is terminal as usual.

- Design Doc.pdf
It is our design document for this project.

- src
this directory contains all the code for this project.

- testscripts
this direcotry contains ten test cases with input and output scripts.